UNSOLVED

[24.4.4](./24.4.md#exercises-244-4)
[24.4.9](./24.4.md#exercises-244-9)
[24.4.11](./24.4.md#exercises-244-11)
[24.4.12](./24.4.md#exercises-244-12)

