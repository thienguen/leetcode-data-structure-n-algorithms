# gantt
Project management using graph data structure
Given an input of milestones for specific tasks, creates a Gantt Chart that shows the critical path.
