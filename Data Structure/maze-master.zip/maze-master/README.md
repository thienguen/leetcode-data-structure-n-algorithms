# maze
Utilizes disjoint sets to generate maze of specified row and column dimensions.
