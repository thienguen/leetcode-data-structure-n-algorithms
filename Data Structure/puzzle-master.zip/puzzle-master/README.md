# puzzle
Word puzzle solver with AVL tree data structure.
